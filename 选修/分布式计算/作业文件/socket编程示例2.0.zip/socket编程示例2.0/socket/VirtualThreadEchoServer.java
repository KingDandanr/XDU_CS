import java.io.*;
import java.net.*;

public class VirtualThreadEchoServer {
    private static final int PORT = 12345; // 服务器端口

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("虚拟线程 Echo 服务器已启动，监听端口：" + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("新客户端连接：" + clientSocket.getRemoteSocketAddress());

                // 为每个客户端创建一个虚拟线程
                Thread.startVirtualThread(() -> handleClient(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket socket) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {

            String message;
            while ((message = reader.readLine()) != null) {
                System.out.println("收到消息: " + message);
                writer.write("Echo: " + message + "\n");
                writer.flush();
            }
        } catch (IOException e) {
            System.out.println("客户端断开连接：" + socket.getRemoteSocketAddress());
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }
}
