import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.net.InetSocketAddress;

public class ProactorServer {
    private static final int PORT = 12345;

    public static void main(String[] args) throws IOException {
        // 创建异步 ServerSocket
        AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open();
        serverChannel.bind(new InetSocketAddress(PORT));
        System.out.println("Proactor Server started, listening on port " + PORT);

        // 异步接受连接
        serverChannel.accept(null, new CompletionHandler<AsynchronousSocketChannel, Void>() {
            @Override
            public void completed(AsynchronousSocketChannel clientChannel, Void attachment) {
                // 继续监听新的连接（重要！否则只处理一次连接）
                serverChannel.accept(null, this);

                // 处理客户端请求
                handleClient(clientChannel);
            }

            @Override
            public void failed(Throwable exc, Void attachment) {
                System.err.println("Connection failed: " + exc.getMessage());
            }
        });

        // 阻止主线程退出（AIO 是异步的，主线程不能立即退出）
        while (true) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private static void handleClient(AsynchronousSocketChannel clientChannel) {
        ByteBuffer buffer = ByteBuffer.allocate(1024);

        // 读取数据（异步）
        clientChannel.read(buffer, buffer, new CompletionHandler<Integer, ByteBuffer>() {
            @Override
            public void completed(Integer bytesRead, ByteBuffer buffer) {
                if (bytesRead == -1) {
                    try {
                        clientChannel.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return;
                }

                buffer.flip();
                String received = new String(buffer.array(), 0, bytesRead);
                System.out.println("Received: " + received);

                // 处理业务逻辑（这里是 Echo 服务器）
                buffer.rewind();
                clientChannel.write(buffer, buffer, new CompletionHandler<Integer, ByteBuffer>() {
                    @Override
                    public void completed(Integer bytesWritten, ByteBuffer buffer) {
                        // 继续读取客户端数据
                        buffer.clear();
                        clientChannel.read(buffer, buffer, this);
                    }

                    @Override
                    public void failed(Throwable exc, ByteBuffer buffer) {
                        System.err.println("Write failed: " + exc.getMessage());
                    }
                });
            }

            @Override
            public void failed(Throwable exc, ByteBuffer buffer) {
                System.err.println("Read failed: " + exc.getMessage());
                try {
                    clientChannel.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
