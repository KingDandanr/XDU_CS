import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.ObjectMessage;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;

public class MyListener implements MessageListener {

	public void onMessage(Message message) {
		try {
			System.out.println("Received a message: "+((TextMessage)message).getText());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
