var http = require('http');
var server = http.createServer(function(req, res){
	res.write("Hello world from Server Foure.");
	res.end();
});
server.listen(2324);

console.log("running at http://127.0.0.1:2324");