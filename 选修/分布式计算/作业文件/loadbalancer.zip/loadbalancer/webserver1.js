var http = require('http');
var server = http.createServer(function(req, res){
	res.write("Hello world from Server One.");
	res.end();
});
server.listen(2321);

console.log("running at http://127.0.0.1:2321");