var http = require('http');
var server = http.createServer(function(req, res){
	res.write("Hello world from Server Three.");
	res.end();
});
server.listen(2323);

console.log("running at http://127.0.0.1:2323");