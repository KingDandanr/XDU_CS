var http = require('http');
var server = http.createServer(function(req, res){
	res.write("Hello world from Server Two.");
	res.end();
});
server.listen(2322);

console.log("running at http://127.0.0.1:2322");