----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 2023/05/16 14:46:12
-- Design Name: 
-- Module Name: FIFOControl - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity FIFOControl is
--  Port ( );
	generic(
		width:positive:=8;	--N
		depth:positive:=8	--M
	);
	port(
		clk:in std_logic;
		rst:in std_logic;
		wr:in std_logic;
		re:in std_logic;
		wrEn:in std_logic;
		reEn:in std_logic;
		dataIn:in std_logic_vector(width-1 downto 0);
		dataOut:out std_logic_vector(width-1 downto 0);
		empty:out std_logic;
		full:out std_logic
	);
end FIFOControl;

architecture Behavioral of FIFOControl is
	type ram is array(0 to depth-1)of std_logic_vector(width-1 downto 0);
	signal dataSum:integer range 0 to depth;
	signal readPtr,writePtr:integer range 0 to depth-1;
	signal myRam:ram;
begin
	process(clk)
	begin
		if rising_edge(clk) then
			if(rst='1') then
				dataSum<=0;
				readPtr<=0;
				writePtr<=0;
			elsif reEn='1'and re='1'and wrEn='0' and wr='0' and dataSum>0 then
				dataOut<=myRam(readPtr);
				readPtr<=(readPtr+1)mod depth;
				dataSum<=dataSum-1;
			elsif reEn='0'and re='0'and wrEn='1' and wr='1' and dataSum<depth then
				myRam(writePtr)<=dataIn;
				writePtr<=(writePtr+1)mod depth;
				dataSum<=dataSum+1;
			end if;
		end if;
	end process;
	
	process(clk)
	begin
		if rising_edge(clk) then
			if dataSum=depth then
				full<='1';
			else
				full<='0';
			end if;
			if dataSum=0 then
				empty<='1';
			else
				empty<='0';
			end if;
		end if;
	end process;
	
end Behavioral;
