package cn.edu.xidian.CrossCounselingSystem.Menu;

import cn.edu.xidian.CrossCounselingSystem.Setting.Settings;
import cn.edu.xidian.CrossCounselingSystem.Setting.SettingsManager;

import java.util.Scanner;

public class SettingMenu {
    public static void show() {
        System.out.println("=== 设置菜单 ===");
        System.out.println("1. 更改API");
        System.out.println("2. 更改中间优化词");
        System.out.println("3. 更改Model1");
        System.out.println("4. 更改Model2");
        System.out.println("0. 返回上一级");
        System.out.print("请输入选项: ");
    }
    public static void run(Scanner scanner, Settings settings){
        show();
        String choice = getChoice(scanner);
        boolean running = true;
        while(running){
            switch (choice) {
                case "1":
                    // 进入设置api环节
                    settings.enterARK_API_KEY(scanner);
                    break;
                case "2":
                    // 进入设置prompt环节
                    settings.enterInternalPrompt(scanner);
                    break;
                case "3":
                    // 进入设置prompt环节
                    settings.enterModelID1(scanner);
                    break;
                case "4":
                    // 进入设置prompt环节
                    settings.enterModelID2(scanner);
                    break;
                case "0":
                    //new ExitAction().run();
                    SettingsManager.saveSettings(settings);
                    return;
                default:
                    System.out.println("无效输入，请重新选择。");
            }
            show();
            choice = getChoice(scanner);
        }
    }
    public static String getChoice(Scanner scanner) {
        return scanner.nextLine();
    }
}
