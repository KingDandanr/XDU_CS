package cn.edu.xidian.CrossCounselingSystem.Setting;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

public class SettingsManager {
    private static final String SETTINGS_FILE = "settings.json";

    private static final ObjectMapper mapper = new ObjectMapper();

    public static Settings loadSettings() {
        File file = new File(SETTINGS_FILE);
        if (!file.exists()) {
            // 文件不存在时返回默认设置
            Settings defaultSettings = new Settings();
            defaultSettings.setUsername("defaultUser");
            defaultSettings.setRefreshInterval(30);
            defaultSettings.setNotificationsEnabled(true);
            defaultSettings.setBehindPrompt("以下是一个语言模型的回答，请你对其进行优化：");
            defaultSettings.setFrontPrompt("");
            defaultSettings.setModelID1("doubao-1-5-pro-32k-250115");
            defaultSettings.setModelID2("doubao-1-5-pro-32k-250115");
            return defaultSettings;
        }

        try {
            return mapper.readValue(file, Settings.class);
        } catch (IOException e) {
            e.printStackTrace();
            // 读取失败时返回默认设置
            return new Settings();
        }
    }

    public static void saveSettings(Settings settings) {
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(SETTINGS_FILE), settings);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
