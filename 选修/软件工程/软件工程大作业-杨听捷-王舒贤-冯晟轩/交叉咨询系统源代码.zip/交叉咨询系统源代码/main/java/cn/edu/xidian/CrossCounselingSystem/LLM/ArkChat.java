package cn.edu.xidian.CrossCounselingSystem.LLM;

import com.volcengine.ark.runtime.model.completion.chat.ChatCompletionRequest;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessageRole;
import com.volcengine.ark.runtime.service.ArkService;
import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class ArkChat {

    /**
     * 开始一个新的对话，不读取历史记录，不进行检查
     * @param apiKey 用户的APIKEY
     * @param modelID 调用模型的ID，要求已经在网站上开通对应的模型
     * @param scanner 统一的系统输入
     */
    public static List<ChatMessage> startNewChat(String apiKey, String modelID, Scanner scanner){
        if (!isAPILegal(apiKey)) {
            return null;
        }

        // 配置 Ark 服务
        String baseUrl = "https://ark.cn-beijing.volces.com/api/v3";
        ArkService service = createArkService(apiKey);
        List<ChatMessage> history = new ArrayList<>();
        System.out.println("✅ 方舟大模型 CLI 已启动，输入 `exit` 退出。");


        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) break;

            // 创建用户消息
            history.add(buildMessage(input,ChatMessageRole.USER));

            // 构造请求
            try {
                String reply = getReplayFromAPI(service,buildRequest(modelID,history));
                System.out.println("🤖 模型回复: " + reply);

                // 添加模型回复到历史
                history.add(buildMessage(reply,ChatMessageRole.ASSISTANT));
            } catch (Exception e) {
                System.err.println("调用失败：" + e.getMessage());
            }
        }

        service.shutdownExecutor();
        System.out.println("👋 会话已结束。");
        return history;
    }

    /**
     * 检查是否apiKey合法，如果不合法，在命令行输出错误信息
     * @param apiKey 火山引擎的apiKey
     * @return is合法？
     */
    public static boolean isAPILegal(String apiKey){
        if (apiKey.isEmpty()) {
            System.err.println("错误：未提供 API Key，程序退出。");
            return false;
        }
        return true;
    }

    /**
     * 创建一个Ark模型api服务，用于后续的使用
     * @param apiKey
     * @return
     */
    public static ArkService createArkService(String apiKey){
        String baseUrl = "https://ark.cn-beijing.volces.com/api/v3";
        ArkService service = ArkService.builder()
                .dispatcher(new Dispatcher())
                .connectionPool(new ConnectionPool(5, 1, TimeUnit.SECONDS))
                .baseUrl(baseUrl)
                .apiKey(apiKey)
                .build();
        return service;
    }

    /**
     * 构建一个消息
     * @param message 输入的文本
     * @param role 此次对话的角色
     * @return 一个ChatMessage类实例
     */
    public static ChatMessage buildMessage(String message,ChatMessageRole role){
        ChatMessage messageBuilding = ChatMessage.builder()
                .role(role)
                .content(message)
                .build();
        return messageBuilding;
    }

    public static ChatCompletionRequest buildRequest(String modelID,List<ChatMessage> history){
        ChatCompletionRequest request = ChatCompletionRequest.builder()
                .model(modelID)
                .messages(history)
                .build();
        return request;
    }

    public static String getReplayFromAPI(ArkService service,ChatCompletionRequest request){
        return service.createChatCompletion(request)
                .getChoices().get(0).getMessage().getContent().toString();
    }

}
