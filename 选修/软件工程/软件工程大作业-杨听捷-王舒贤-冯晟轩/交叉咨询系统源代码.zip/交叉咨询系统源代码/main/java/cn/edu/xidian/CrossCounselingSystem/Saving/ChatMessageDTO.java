package cn.edu.xidian.CrossCounselingSystem.Saving;

import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessageRole;

public class ChatMessageDTO {
    private ChatMessageRole role;
    private String content;

    public ChatMessageDTO() {
    }

    public ChatMessageDTO(ChatMessageRole role, String content) {
        this.role = role;
        this.content = content;
    }

    public ChatMessageRole getRole() {
        return role;
    }

    public void setRole(ChatMessageRole role) {
        this.role = role;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public static ChatMessageDTO toDTO(ChatMessage msg) {
        return new ChatMessageDTO(msg.getRole(), msg.stringContent());
    }

    public static ChatMessage fromDTO(ChatMessageDTO dto) {
        return ChatMessage.builder().role(dto.getRole())
                .content(dto.getContent()).build();
    }

}
