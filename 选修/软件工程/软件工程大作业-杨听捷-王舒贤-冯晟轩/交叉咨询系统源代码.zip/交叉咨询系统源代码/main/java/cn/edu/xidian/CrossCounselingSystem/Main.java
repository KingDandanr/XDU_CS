package cn.edu.xidian.CrossCounselingSystem;

import cn.edu.xidian.CrossCounselingSystem.LLM.ArkChat;
import cn.edu.xidian.CrossCounselingSystem.LLM.LLMManager;
import cn.edu.xidian.CrossCounselingSystem.Menu.LoadMenu;
import cn.edu.xidian.CrossCounselingSystem.Menu.MainMenu;
import cn.edu.xidian.CrossCounselingSystem.Menu.SettingMenu;
import cn.edu.xidian.CrossCounselingSystem.Saving.HistoryManager;
import cn.edu.xidian.CrossCounselingSystem.Setting.Settings;
import cn.edu.xidian.CrossCounselingSystem.Setting.SettingsManager;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) throws IOException {
        // init
        Settings settings = SettingsManager.loadSettings();
        File historyDir = new File("history");
        if (!historyDir.exists()) {
            if(!historyDir.mkdirs()){
                System.out.println("创建保存路径失败");
                return;
            };
        }

        // scanner of the system
        Scanner scanner = new Scanner(System.in);
        System.out.println("当前设置:");
        System.out.println(settings);

        boolean running = true;
        // main loop
        while (running) {
            MainMenu.show();
            String choice = MainMenu.getChoice(scanner);
            List<ChatMessage> temp;
            switch (choice) {
                case "1":
                    // 开始一段新的对话
                    temp = ArkChat.startNewChat(settings.getARK_API_KEY(), settings.getModelID1(), scanner);
                    if (temp == null) break;
                    HistoryManager.saveHistory(UUID.randomUUID(), temp);
                    break;
                case "2":
                    // 开始一段新的对话,带有优化
                    temp = LLMManager.startNewChat(settings, settings.getModelID1(), settings.getModelID2(), scanner);
                    if (temp == null) break;
                    HistoryManager.saveHistory(UUID.randomUUID(), temp);
                    break;
                case "3":
                    // 开始一段新的对话,带有优化
                    LoadMenu.run(scanner,settings);
                    break;
                case "#":
                    // 开始一段新的对话
                    SettingMenu.run(scanner, settings);
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("无效输入，请重新选择。");
            }

            System.out.println(); // 空行分隔
        }

        // end program
        // save setting
        SettingsManager.saveSettings(settings);

        scanner.close();
    }
}
