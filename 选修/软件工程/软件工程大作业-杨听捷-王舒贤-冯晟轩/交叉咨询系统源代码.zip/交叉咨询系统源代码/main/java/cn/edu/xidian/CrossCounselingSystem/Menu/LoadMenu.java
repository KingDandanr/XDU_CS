package cn.edu.xidian.CrossCounselingSystem.Menu;

import cn.edu.xidian.CrossCounselingSystem.LLM.LLMManager;
import cn.edu.xidian.CrossCounselingSystem.Saving.HistoryManager;
import cn.edu.xidian.CrossCounselingSystem.Setting.Settings;
import cn.edu.xidian.CrossCounselingSystem.Setting.SettingsManager;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class LoadMenu {


    public static void show() {
        System.out.println("=== 读取 ===");
        System.out.println("1. 显示所有历史");
        System.out.println("2. 根据ID读取");
        System.out.println("0. 返回上一级");
        System.out.print("请输入选项: ");
    }

    public static void run(Scanner scanner, Settings settings) throws IOException {
        show();
        String choice = getChoice(scanner);
        boolean running = true;
        while (running) {
            switch (choice) {
                case "1":
                    // 进入设置api环节
                    HistoryManager.listSavedHistories();
                    break;
                case "2":
                    // 进入设置prompt环节
                    System.out.println("请输入UUID：");
                    UUID uuid= UUID.fromString(scanner.nextLine());
                    List<ChatMessage> messages = HistoryManager.loadHistory(uuid);
                    for(ChatMessage message:messages){
                        System.out.println(message.getRole()+":"+message.stringContent());
                    }
                    messages = LLMManager.LoadChat(settings, settings.getModelID1(), settings.getModelID2(), scanner,messages);
                    HistoryManager.saveHistory(uuid,messages);
                    break;
                case "0":
                    //new ExitAction().run();
                    SettingsManager.saveSettings(settings);
                    return;
                default:
                    System.out.println("无效输入，请重新选择。");
            }
            show();
            choice = getChoice(scanner);
        }
    }

    public static String getChoice(Scanner scanner) {
        return scanner.nextLine();
    }
}
