package cn.edu.xidian.CrossCounselingSystem.Saving;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class HistoryManager {
    public static void saveHistory(UUID uuid, List<ChatMessage> messages) throws IOException {
        ObjectMapper mapper = new ObjectMapper();

        // 将 ChatMessage 转换成 DTO
        List<ChatMessageDTO> dtoList = messages.stream()
                .map(ChatMessageDTO::toDTO)
                .collect(Collectors.toList());

        // 保存到 history/<uuid>.json
        File file = new File("history", uuid.toString() + ".json");
        mapper.writeValue(file, dtoList);
    }
    public static List<ChatMessage> loadHistory(UUID uuid) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        File file = new File("history", uuid.toString() + ".json");

        if (!file.exists()) return new ArrayList<>();

        List<ChatMessageDTO> dtoList = mapper.readValue(file, new TypeReference<List<ChatMessageDTO>>() {});
        return dtoList.stream()
                .map(ChatMessageDTO::fromDTO)
                .collect(Collectors.toList());
    }

    public static List<UUID> listSavedHistories() throws IOException {
        File folder = new File("history");
        if (!folder.exists()) return Collections.emptyList();

        File[] files = folder.listFiles((dir, name) -> name.endsWith(".json"));
        if (files == null) return Collections.emptyList();

        List<UUID> temp = Arrays.stream(files)
                .map(file -> file.getName().replace(".json", ""))
                .map(UUID::fromString)
                .collect(Collectors.toList());
        for(UUID uuid: temp){
            List<ChatMessage> tempChatMessage;
            System.out.println(uuid.toString());
            tempChatMessage = loadHistory(uuid);
            System.out.println(tempChatMessage.getFirst().stringContent());
            System.out.println();
        }
        return temp;
    }



}
