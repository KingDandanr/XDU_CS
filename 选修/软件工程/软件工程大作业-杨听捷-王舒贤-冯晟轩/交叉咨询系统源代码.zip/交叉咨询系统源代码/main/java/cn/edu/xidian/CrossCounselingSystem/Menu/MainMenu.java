package cn.edu.xidian.CrossCounselingSystem.Menu;

import java.util.Scanner;
    public class MainMenu {
        public static void show() {
            System.out.println("=== 主菜单 ===");
            System.out.println("1. 开始新的对话");
            System.out.println("2. 开始新的对话（带有优化）");
            System.out.println("3. 读取");
            System.out.println("#. 设置");
            System.out.println("0. 退出程序");
            System.out.print("请输入选项: ");
        }

        public static String getChoice(Scanner scanner) {
            return scanner.nextLine();
        }

    }


