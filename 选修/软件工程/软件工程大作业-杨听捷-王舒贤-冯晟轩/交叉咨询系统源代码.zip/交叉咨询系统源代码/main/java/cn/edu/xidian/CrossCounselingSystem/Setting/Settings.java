package cn.edu.xidian.CrossCounselingSystem.Setting;

import java.util.Scanner;

public class Settings {
    private String username;
    private int refreshInterval;
    private boolean notificationsEnabled;
    private String ARK_API_KEY;
    private String frontPrompt;
    private String behindPrompt;
    private String ModelID1;
    private String ModelID2;

    public Settings() {
        // 默认构造器，Jackson需要
    }

    public void enterARK_API_KEY(Scanner scanner) {
        // String apiKey = System.getenv("ARK_API_KEY");
        String apiKey = "";
        System.out.print("请输入您的 API Key：");
        apiKey = scanner.nextLine().trim();
        setARK_API_KEY(apiKey);
    }


    public void enterInternalPrompt(Scanner scanner) {
        String internalPrompt = "";
        System.out.println("请输入您的优化语句。");
        System.out.print("前语句：");
        setFrontPrompt(scanner.nextLine().trim());
        System.out.print("后语句：");
        setBehindPrompt(scanner.nextLine().trim());
    }
    public void enterModelID1(Scanner scanner) {
        String modelID = "";
        System.out.print("请输入您要调用的模型ID：");
        setModelID1(scanner.nextLine().trim());
    }
    public void enterModelID2(Scanner scanner) {
        String modelID = "";
        System.out.print("请输入您要调用的模型ID：");
        setModelID2(scanner.nextLine().trim());
    }



    // getter & setter

    public String getModelID1() {
        return ModelID1;
    }

    public void setModelID1(String modelID1) {
        ModelID1 = modelID1;
    }

    public String getModelID2() {
        return ModelID2;
    }

    public void setModelID2(String modelID2) {
        ModelID2 = modelID2;
    }


    public String getFrontPrompt() {
        return frontPrompt;
    }

    public void setFrontPrompt(String frontPrompt) {
        this.frontPrompt = frontPrompt;
    }

    public String getBehindPrompt() {
        return behindPrompt;
    }

    public void setBehindPrompt(String behindPrompt) {
        this.behindPrompt = behindPrompt;
    }

    public String getARK_API_KEY() {
        return ARK_API_KEY;
    }

    public void setARK_API_KEY(String ARK_API_KEY) {
        this.ARK_API_KEY = ARK_API_KEY;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getRefreshInterval() {
        return refreshInterval;
    }

    public void setRefreshInterval(int refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    public boolean isNotificationsEnabled() {
        return notificationsEnabled;
    }

    public void setNotificationsEnabled(boolean notificationsEnabled) {
        this.notificationsEnabled = notificationsEnabled;
    }

    @Override
    public String toString() {
        return "Settings{" +
                "username='" + username + '\'' +
                ", refreshInterval=" + refreshInterval +
                ", notificationsEnabled=" + notificationsEnabled +
                '}';
    }
}
