package cn.edu.xidian.CrossCounselingSystem.LLM;


import cn.edu.xidian.CrossCounselingSystem.Setting.Settings;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessage;
import com.volcengine.ark.runtime.model.completion.chat.ChatMessageRole;
import com.volcengine.ark.runtime.service.ArkService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class LLMManager {
    public static List<ChatMessage> startNewChat(Settings settings, String modelID1,String modelID2,Scanner scanner) {
        String apiKey = settings.getARK_API_KEY();
        if (!ArkChat.isAPILegal(apiKey)) {
            return null;
        }

        //配置Ark服务
        String baseUrl = "https://ark.cn-beijing.volces.com/api/v3";
        ArkService service = ArkChat.createArkService(apiKey);
        List<ChatMessage> history = new ArrayList<>();
        System.out.println("✅ 大模型 CLI 已启动，输入 `exit` 退出。");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) break;

            // 创建用户消息
            history.add(ArkChat.buildMessage(input, ChatMessageRole.USER));

            String reply = "";
            // 构造请求
            try {
                reply = ArkChat.getReplayFromAPI(service, ArkChat.buildRequest(modelID1, history));
                System.out.println("🤖 模型回复: " + reply);
            } catch (Exception e) {
                System.err.println("调用失败：" + e.getMessage());
            }
            System.out.println("-----------");
            System.out.println("开始二次优化");
            System.out.println("-----------");
            List<ChatMessage> temp = new ArrayList<>();
            temp.add(ArkChat.buildMessage(
                    settings.getFrontPrompt() + reply + settings.getBehindPrompt(),
                    ChatMessageRole.USER));
            try {
                reply = ArkChat.getReplayFromAPI(service, ArkChat.buildRequest(modelID2, temp));
                System.out.println("🤖 模型二次优化: " + reply);

                //添加模型回复到历史
                history.add(ArkChat.buildMessage(reply, ChatMessageRole.ASSISTANT));
            } catch (Exception e) {
                System.err.println("调用失败：" + e.getMessage());
            }
        }

        service.shutdownExecutor();
        System.out.println("👋 会话已结束。");
        return history;
    }
    public static List<ChatMessage> LoadChat(Settings settings, String modelID1,String modelID2,Scanner scanner,List<ChatMessage> history){
        String apiKey = settings.getARK_API_KEY();
        if (!ArkChat.isAPILegal(apiKey)) {
            return null;
        }

        //配置Ark服务
        String baseUrl = "https://ark.cn-beijing.volces.com/api/v3";
        ArkService service = ArkChat.createArkService(apiKey);
        System.out.println("✅ 大模型 CLI 已启动，输入 `exit` 退出。");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("exit")) break;

            // 创建用户消息
            history.add(ArkChat.buildMessage(input, ChatMessageRole.USER));

            String reply = "";
            // 构造请求
            try {
                reply = ArkChat.getReplayFromAPI(service, ArkChat.buildRequest(modelID1, history));
                System.out.println("🤖 模型回复: " + reply);
            } catch (Exception e) {
                System.err.println("调用失败：" + e.getMessage());
            }
            System.out.println("-----------");
            System.out.println("开始二次优化");
            System.out.println("-----------");
            List<ChatMessage> temp = new ArrayList<>();
            temp.add(ArkChat.buildMessage(
                    settings.getFrontPrompt() + reply + settings.getBehindPrompt(),
                    ChatMessageRole.USER));
            try {
                reply = ArkChat.getReplayFromAPI(service, ArkChat.buildRequest(modelID2, temp));
                System.out.println("🤖 模型二次优化: " + reply);

                //添加模型回复到历史
                history.add(ArkChat.buildMessage(reply, ChatMessageRole.ASSISTANT));
            } catch (Exception e) {
                System.err.println("调用失败：" + e.getMessage());
            }
        }

        service.shutdownExecutor();
        System.out.println("👋 会话已结束。");
        return history;
    }

}
